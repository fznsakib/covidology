// var countryA = $(".ytick")[0].firstChild.textContent;
// var casesA = $(".ytick")[1].firstChild.textContent;
//
// var countryB = $(".ytick2")[1].firstChild.textContent;
// var casesB = $(".ytick2")[0].firstChild.textContent;
//
// $("#firstPlace").text(countryB);
// $("#firstPlaceCount").text("Cases: " + casesB);
// $("#secondPlace").text(countryA);
// $("#secondPlaceCount").text("Cases: " + casesA);
//
